﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CafeShopSiparis
{
    public class BaseClass
    {
        public string Name { get; set; }
        public float Price { get; set; }
        public decimal OrderAmount { get; set; }

        public override string ToString()
        {
            return Name;
        }
        
    }
}
