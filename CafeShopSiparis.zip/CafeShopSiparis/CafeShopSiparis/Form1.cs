using static System.Windows.Forms.LinkLabel;

namespace CafeShopSiparis
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        decimal total;
        decimal totalPrice;
        private void Form1_Load(object sender, EventArgs e)
        {
            Drink turkishCoffee = new Drink() { Name = "Turkish Coffee", Price = 80f };
            Drink latte = new Drink() { Name = "Latte", Price = 75f };
            Drink americano = new Drink() { Name = "Americano", Price = 120f };
            Drink mokka = new Drink() { Name = "Mocca", Price = 140f };

            cmbDrinks.Items.Add(turkishCoffee);
            cmbDrinks.Items.Add(latte);
            cmbDrinks.Items.Add(americano);
            cmbDrinks.Items.Add(mokka);

            Food friedPotatoes = new Food() { Name = "Fried Potatoes", Price = 40f };
            Food cake = new Food() { Name = "Cake", Price = 60f };
            Food sandwich = new Food() { Name = "Sandwich", Price = 125f };
            Food hamburger = new Food() { Name = "Hamburger", Price = 200f };

            cmbFoods.Items.Add(friedPotatoes);
            cmbFoods.Items.Add(cake);
            cmbFoods.Items.Add(sandwich);
            cmbFoods.Items.Add(hamburger);

            Dessert icecream = new Dessert() { Name = "Ice Cream", Price = 45f };
            Dessert baklava = new Dessert() { Name = "Baklava", Price = 145f };

            cmbDesserts.Items.Add(baklava);
            cmbDesserts.Items.Add(icecream);


        }
        List<BaseClass> sp = new List<BaseClass>();
        private void btnACalculate_Click(object sender, EventArgs e)
        {

            lstBasket.Items.Clear();
            if (cmbDrinks.SelectedItem != null)
            {
                Drink drink = cmbDrinks.SelectedItem as Drink;
                if (nmDrink.Value != 0)
                {
                    drink.OrderAmount = nmDrink.Value;
                    if (!sp.Contains(drink))
                    {
                        sp.Add(drink);
                    }
                    else
                    {
                        drink.OrderAmount = nmDrink.Value;
                    }
                }
                else
                {
                    sp.Remove(drink);
                }
            }

            if (cmbFoods.SelectedItem != null)
            {
                Food food = cmbFoods.SelectedItem as Food;
                if (nmFood.Value != 0)
                {
                    food.OrderAmount = nmFood.Value;
                    if (!sp.Contains(food))
                    {
                        sp.Add(food);
                    }
                    else
                    {
                        food.OrderAmount = nmFood.Value;
                    }
                }
                else
                {
                    sp.Remove(food);
                }
            }

            if (cmbDesserts.SelectedItem != null)
            {
                Dessert dessert = cmbDesserts.SelectedItem as Dessert;
                if (nmDessert.Value != 0)
                {
                    dessert.OrderAmount = nmDessert.Value;
                    if (!sp.Contains(dessert))
                    {
                        sp.Add(dessert);
                    }
                    else
                    {
                        dessert.OrderAmount = nmDessert.Value;
                    }
                }
                else
                {
                    sp.Remove(dessert);
                }
            }
            total = 0;
            foreach (BaseClass item in sp)
            {
                lstBasket.Items.Add($"{item.Name} x {item.OrderAmount}");
                total += (decimal)item.Price * item.OrderAmount;
                lstBasket.DisplayMember = item.OrderAmount.ToString();
            }

            txtTotalPrice.Text = total.ToString();
            totalPrice += total;


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ResetOrder();
        }

        private void ResetOrder()
        {
            cmbDesserts.SelectedIndex = -1;
            cmbDrinks.SelectedIndex = -1;
            cmbFoods.SelectedIndex = -1;
            nmDrink.Value = 0;
            nmDessert.Value = 0;
            nmFood.Value = 0;
            lstBasket.Items.Clear();
            sp.Clear();
            total = 0;

            txtTotalPrice.Text = "0";
        }

        string order = "";
        List<string> orderList = new List<string>();
        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            try
            {
                lstOrders.Items.Clear();
                order = "";
                foreach (var item in lstBasket.Items)
                {
                    order += item.ToString() + " - ";
                }
                order = order.Substring(0, order.Length - 2);
                orderList.Add(order);
                foreach (var item2 in orderList)
                {
                    lstOrders.Items.Add(item2);
                }
                ResetOrder();
            }
            catch (Exception)
            {

                MessageBox.Show("Order list is already deleted.");
            }
            
        }

        private void btnDeleteOrders_Click(object sender, EventArgs e)
        {
            lstOrders.Items.Clear();
            txtOrderPrice.Text = "0";
            totalPrice = 0;
            total = 0;
            orderList.Clear();
        }

        private void btnConfirmOrders_Click(object sender, EventArgs e)
        {
            //lstOrders.Items.Count

            txtTax.Text = (totalPrice * 0.18m).ToString();
            txtOrderPrice.Text = totalPrice.ToString();
            txtTotalTaxPrice.Text = (totalPrice + totalPrice * 0.18m).ToString();
        }
    }
}
