﻿namespace CafeShopSiparis
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cmbDrinks = new ComboBox();
            label2 = new Label();
            cmbFoods = new ComboBox();
            label3 = new Label();
            cmbDesserts = new ComboBox();
            lstBasket = new ListBox();
            btnDelete = new Button();
            label4 = new Label();
            txtTotalPrice = new TextBox();
            lstOrders = new ListBox();
            label5 = new Label();
            btnAddOrder = new Button();
            btnDeleteOrders = new Button();
            btnConfirmOrders = new Button();
            label6 = new Label();
            txtOrderPrice = new TextBox();
            panel1 = new Panel();
            label9 = new Label();
            label7 = new Label();
            label8 = new Label();
            nmDrink = new NumericUpDown();
            nmFood = new NumericUpDown();
            nmDessert = new NumericUpDown();
            label10 = new Label();
            btnAddCalculate = new Button();
            label11 = new Label();
            txtTax = new TextBox();
            label12 = new Label();
            txtTotalTaxPrice = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmDrink).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmFood).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmDessert).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(33, 74);
            label1.Name = "label1";
            label1.Size = new Size(47, 15);
            label1.TabIndex = 0;
            label1.Text = "DRINKS";
            // 
            // cmbDrinks
            // 
            cmbDrinks.BackColor = Color.Azure;
            cmbDrinks.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            cmbDrinks.FormattingEnabled = true;
            cmbDrinks.Location = new Point(33, 92);
            cmbDrinks.Name = "cmbDrinks";
            cmbDrinks.Size = new Size(170, 29);
            cmbDrinks.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(33, 122);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 0;
            label2.Text = "FOODS";
            // 
            // cmbFoods
            // 
            cmbFoods.BackColor = Color.LightCyan;
            cmbFoods.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            cmbFoods.FormattingEnabled = true;
            cmbFoods.Location = new Point(33, 140);
            cmbFoods.Name = "cmbFoods";
            cmbFoods.Size = new Size(170, 29);
            cmbFoods.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 174);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 0;
            label3.Text = "DESSERTS";
            // 
            // cmbDesserts
            // 
            cmbDesserts.BackColor = Color.PaleTurquoise;
            cmbDesserts.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            cmbDesserts.FormattingEnabled = true;
            cmbDesserts.Location = new Point(33, 192);
            cmbDesserts.Name = "cmbDesserts";
            cmbDesserts.Size = new Size(170, 29);
            cmbDesserts.TabIndex = 1;
            // 
            // lstBasket
            // 
            lstBasket.BackColor = Color.PaleTurquoise;
            lstBasket.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lstBasket.FormattingEnabled = true;
            lstBasket.ItemHeight = 21;
            lstBasket.Location = new Point(33, 255);
            lstBasket.Name = "lstBasket";
            lstBasket.Size = new Size(253, 109);
            lstBasket.TabIndex = 2;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.Location = new Point(204, 412);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(82, 51);
            btnDelete.TabIndex = 3;
            btnDelete.Text = "DELETE BASKET";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 496);
            label4.Name = "label4";
            label4.Size = new Size(73, 15);
            label4.TabIndex = 0;
            label4.Text = "TOTAL PRICE";
            // 
            // txtTotalPrice
            // 
            txtTotalPrice.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            txtTotalPrice.Location = new Point(106, 493);
            txtTotalPrice.Name = "txtTotalPrice";
            txtTotalPrice.Size = new Size(91, 29);
            txtTotalPrice.TabIndex = 4;
            // 
            // lstOrders
            // 
            lstOrders.BackColor = Color.GreenYellow;
            lstOrders.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lstOrders.FormattingEnabled = true;
            lstOrders.ItemHeight = 21;
            lstOrders.Location = new Point(313, 90);
            lstOrders.Name = "lstOrders";
            lstOrders.Size = new Size(559, 277);
            lstOrders.TabIndex = 2;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(313, 72);
            label5.Name = "label5";
            label5.Size = new Size(50, 15);
            label5.TabIndex = 0;
            label5.Text = "ORDERS";
            // 
            // btnAddOrder
            // 
            btnAddOrder.BackColor = Color.GreenYellow;
            btnAddOrder.Location = new Point(307, 412);
            btnAddOrder.Name = "btnAddOrder";
            btnAddOrder.Size = new Size(82, 51);
            btnAddOrder.TabIndex = 3;
            btnAddOrder.Text = "ADD ORDER";
            btnAddOrder.UseVisualStyleBackColor = false;
            btnAddOrder.Click += btnAddOrder_Click;
            // 
            // btnDeleteOrders
            // 
            btnDeleteOrders.BackColor = Color.Red;
            btnDeleteOrders.Location = new Point(404, 412);
            btnDeleteOrders.Name = "btnDeleteOrders";
            btnDeleteOrders.Size = new Size(123, 51);
            btnDeleteOrders.TabIndex = 3;
            btnDeleteOrders.Text = "DELETE ORDERS";
            btnDeleteOrders.UseVisualStyleBackColor = false;
            btnDeleteOrders.Click += btnDeleteOrders_Click;
            // 
            // btnConfirmOrders
            // 
            btnConfirmOrders.BackColor = Color.Fuchsia;
            btnConfirmOrders.Location = new Point(542, 412);
            btnConfirmOrders.Name = "btnConfirmOrders";
            btnConfirmOrders.Size = new Size(123, 51);
            btnConfirmOrders.TabIndex = 3;
            btnConfirmOrders.Text = "CONFIRM ORDERS";
            btnConfirmOrders.UseVisualStyleBackColor = false;
            btnConfirmOrders.Click += btnConfirmOrders_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(697, 452);
            label6.Name = "label6";
            label6.Size = new Size(78, 15);
            label6.TabIndex = 0;
            label6.Text = "ORDER PRICE";
            // 
            // txtOrderPrice
            // 
            txtOrderPrice.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            txtOrderPrice.Location = new Point(781, 449);
            txtOrderPrice.Name = "txtOrderPrice";
            txtOrderPrice.Size = new Size(91, 29);
            txtOrderPrice.TabIndex = 4;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MediumSlateBlue;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label7);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(901, 58);
            panel1.TabIndex = 5;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BorderStyle = BorderStyle.FixedSingle;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label9.Location = new Point(875, 9);
            label9.Name = "label9";
            label9.Size = new Size(17, 17);
            label9.TabIndex = 1;
            label9.Text = "X";
            label9.Click += label9_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 19F, FontStyle.Bold);
            label7.Location = new Point(325, 9);
            label7.Name = "label7";
            label7.Size = new Size(340, 36);
            label7.TabIndex = 0;
            label7.Text = "CAFESHOP ORDERS FORM";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(33, 237);
            label8.Name = "label8";
            label8.Size = new Size(47, 15);
            label8.TabIndex = 0;
            label8.Text = "BASKET";
            // 
            // nmDrink
            // 
            nmDrink.BackColor = Color.Azure;
            nmDrink.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            nmDrink.Location = new Point(218, 92);
            nmDrink.Name = "nmDrink";
            nmDrink.Size = new Size(68, 29);
            nmDrink.TabIndex = 6;
            // 
            // nmFood
            // 
            nmFood.BackColor = Color.LightCyan;
            nmFood.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            nmFood.Location = new Point(218, 140);
            nmFood.Name = "nmFood";
            nmFood.Size = new Size(68, 29);
            nmFood.TabIndex = 6;
            // 
            // nmDessert
            // 
            nmDessert.BackColor = Color.PaleTurquoise;
            nmDessert.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            nmDessert.Location = new Point(218, 192);
            nmDessert.Name = "nmDessert";
            nmDessert.Size = new Size(68, 29);
            nmDessert.TabIndex = 6;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(218, 74);
            label10.Name = "label10";
            label10.Size = new Size(28, 15);
            label10.TabIndex = 0;
            label10.Text = "PCS";
            // 
            // btnAddCalculate
            // 
            btnAddCalculate.BackColor = Color.PaleTurquoise;
            btnAddCalculate.Location = new Point(33, 412);
            btnAddCalculate.Name = "btnAddCalculate";
            btnAddCalculate.Size = new Size(102, 51);
            btnAddCalculate.TabIndex = 7;
            btnAddCalculate.Text = "ADD to ORDERS CALCULATE";
            btnAddCalculate.UseVisualStyleBackColor = false;
            btnAddCalculate.Click += btnACalculate_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(748, 408);
            label11.Name = "label11";
            label11.Size = new Size(27, 15);
            label11.TabIndex = 0;
            label11.Text = "TAX";
            // 
            // txtTax
            // 
            txtTax.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            txtTax.Location = new Point(781, 405);
            txtTax.Name = "txtTax";
            txtTax.Size = new Size(91, 29);
            txtTax.TabIndex = 4;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(690, 496);
            label12.Name = "label12";
            label12.Size = new Size(85, 15);
            label12.TabIndex = 0;
            label12.Text = "TOTAL ORDERS";
            // 
            // txtTotalTaxPrice
            // 
            txtTotalTaxPrice.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            txtTotalTaxPrice.Location = new Point(781, 493);
            txtTotalTaxPrice.Name = "txtTotalTaxPrice";
            txtTotalTaxPrice.Size = new Size(91, 29);
            txtTotalTaxPrice.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(901, 553);
            Controls.Add(btnAddCalculate);
            Controls.Add(nmDessert);
            Controls.Add(nmFood);
            Controls.Add(nmDrink);
            Controls.Add(panel1);
            Controls.Add(txtTax);
            Controls.Add(txtTotalTaxPrice);
            Controls.Add(txtOrderPrice);
            Controls.Add(txtTotalPrice);
            Controls.Add(btnDelete);
            Controls.Add(btnConfirmOrders);
            Controls.Add(btnDeleteOrders);
            Controls.Add(btnAddOrder);
            Controls.Add(lstOrders);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(lstBasket);
            Controls.Add(label6);
            Controls.Add(cmbDesserts);
            Controls.Add(label4);
            Controls.Add(label8);
            Controls.Add(label3);
            Controls.Add(cmbFoods);
            Controls.Add(label2);
            Controls.Add(cmbDrinks);
            Controls.Add(label5);
            Controls.Add(label10);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmDrink).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmFood).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmDessert).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox cmbDrinks;
        private Label label2;
        private ComboBox cmbFoods;
        private Label label3;
        private ComboBox cmbDesserts;
        private ListBox lstBasket;
        private Button btnAddBasket;
        private Button btnDelete;
        private Label label4;
        private TextBox txtTotalPrice;
        private ListBox lstOrders;
        private Label label5;
        private Button btnAddOrder;
        private Button btnDeleteOrders;
        private Button btnConfirmOrders;
        private Label label6;
        private TextBox txtOrderPrice;
        private Panel panel1;
        private Label label7;
        private Label label8;
        private Label label9;
        private NumericUpDown nmDrink;
        private NumericUpDown nmFood;
        private NumericUpDown nmDessert;
        private Label label10;
        private Button btnAddCalculate;
        private Label label11;
        private TextBox txtTax;
        private Label label12;
        private TextBox txtTotalTaxPrice;
    }
}
